class HuffmanTree(object):
    def __init__(self, symbol=None, left=None, right=None, freq=None): 
        print("Not implemented yet")

    def read_dict(self, d):

        print("Not implemented yet")

    def find_char(self, code):
        print("Not implemented yet")

    def __add__(self, other): 
        print("Not implemented yet")

    def __lt__(self, other): 
        print("Not implemented yet")
    
    def get_codes(self, prefix = ""):
        print("Not implemented yet")

